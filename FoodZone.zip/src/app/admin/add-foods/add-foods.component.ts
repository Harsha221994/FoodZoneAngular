import { Component, OnInit } from '@angular/core';
import { FoodService } from 'src/app/home/food.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-add-foods',
  templateUrl: './add-foods.component.html',
  styleUrls: ['./add-foods.component.css']
})
export class AddFoodsComponent implements OnInit {

  constructor(private _service:FoodService,private _snackBar:MatSnackBar) { }
 foodList=[]
 beverageList=[]
  ngOnInit() {
    fetch('assets/Food.json').then(data=>data.json()).then(data=>{
      this.beverageList=data.data.beverages
      this.foodList=data.data.items
      console.log(this.beverageList)
      console.log(this.foodList)
    })
  }
  selectedType
  selectedItem
  offer
  addFood(food,bev){
    if(food!=undefined)
    {
      food.offer=`${this.offer}%`
      food.quantity=1
      food.type=this.selectedType
      this._service.addFood(food).subscribe(data=> this._snackBar.open("Added Food Successfully","OK",{
        duration:2000
            }))
    } 
    else if(bev!=undefined){
      bev.offer=`${this.offer}%`
      bev.quantity=1
      this._service.addFood(bev).subscribe(data=>this._snackBar.open("Added Beverage Successfully","OK",{
        duration:2000
            }))
    }
  }
  
}
