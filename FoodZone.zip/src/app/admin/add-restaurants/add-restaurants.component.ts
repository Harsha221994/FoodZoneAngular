import { Component, OnInit } from '@angular/core';
import { FoodService } from 'src/app/home/food.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-add-restaurants',
  templateUrl: './add-restaurants.component.html',
  styleUrls: ['./add-restaurants.component.css']
})
export class AddRestaurantsComponent implements OnInit {

  constructor(private _service:FoodService,private _snackBar:MatSnackBar) { }
  restaurants=[]
basvanagudiRestaurants=["Truffles","Nagarjuna Chimney"]
JPNagarRestaurants=["Roti ghar","Vijaylakshmi veg"]
  selectedLoc
  selectedRes
  onChange(){
    if(this.selectedLoc=="JP Nagar"){
      this.restaurants=this.basvanagudiRestaurants
    }
    else if(this.selectedLoc=="Basavanagudi")
  {
    this.restaurants=this.JPNagarRestaurants
  }    
  }
  addRes(){
    fetch('assets/products.json').then(data=>data.json()).then(data=>{
      console.log(data)
      let obj={
        "location":this.selectedLoc,
        "restaurants":[]
      }
      if(this.selectedLoc=="Basavanagudi")
      {
       // let obj=data.Restaurants[2]['restaurants'][2]['products']
        obj["placeURL"]="https://static.gamifyi.com/images/Bengaluru/Basavangudi/FoodTrail/BasavanagudiFoodTrail_web_small.jpg"
           if(this.selectedRes=="Roti ghar" )
            {
              obj["restaurants"].push({
                name:"Roti Ghar",
                rating:4.1,
                reviews:11836,
                address:"Gandhi Bazaar, Basavanagudi, Bengaluru, Karnataka 560004",
                products:data.Restaurants[2]['restaurants'][2]['products'],
                openingHours:"7:30am-9:30pm", 
               imgUrl:"https://lh3.googleusercontent.com/ILHne3xj6gMmmaUiAVxj4mZbfCq9ASTpwBsl9Qg8L5Yh22jP8qSWsyqPznOVXXOwoS-2DUHQ7qQfdUN1FsUKNykSh6Q=w1000",
               url:"https://www.google.com/maps/dir//roti+ghar/@12.9685703,77.5487041,12z/data=!4m8!4m7!1m0!1m5!1m1!1s0x3bae15f2ea1eda2f:0xe74c5463097e8ee5!2m2!1d77.5718769!2d12.9448063"
              })
            }
            else if(this.selectedRes=="Vijaylakshmi veg"){
              obj["restaurants"].push({
                name:"Vijayalakshmi veg",
                rating:4.3,
                reviews:30095,
                address:"Bull Temple Rd, Gandhi Bazaar, Basavanagudi, Bengaluru, Karnataka 560004",
                openingHours:"7:30am-9:30pm",  
               products:data.Restaurants[2]['restaurants'][2]['products'],
               imgUrl:"https://www.google.com/maps/place/Vidyarthi+Bhavan/@12.9330989,77.5586662,17z/data=!4m5!3m4!1s0x3bae15f2e88ad035:0xed7fede7791f8edc!8m2!3d12.945072!4d77.571343?hl=en",
               url:"https://www.google.com/maps/place/VIJAYALAKSHMI+VEG/@12.9452054,77.5657324,17z/data=!3m1!4b1!4m5!3m4!1s0x3bae1542b20a7743:0x5b6948152e8d9f93!8m2!3d12.9452054!4d77.5679211?hl=en"
              })
            }
      }else if(this.selectedLoc=="JP Nagar"){
        obj["placeURL"]="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQngtB0q6d-Io720EAmjW-eHRCadVmuoGKxFg&usqp=CAU"
        if(this.selectedRes=="Truffles"){
          obj["restaurants"].push({
            name:"Truffles",
            rating:4.5,
            reviews:34590,
            address:"Apex Building 93/A Ground Floor, A Wing, 4th B Cross Rd, 5th Block, Koramangala, Bengaluru, Karnataka 560095",
            openingHours:"7:30am-9:30pm",  
            products:data.Restaurants[3]['restaurants'][3]['products'],
           imgUrl:"https://res.cloudinary.com/swiggy/image/upload/f_auto,q_auto,fl_lossy/xqn3fpnwialxgyl52eqw",
           url:"https://www.google.com/maps/place/Truffles/@12.9336352,77.6120463,17z/data=!3m1!4b1!4m5!3m4!1s0x3bae1451d90b3e77:0x6297032c180f2bbd!8m2!3d12.9336352!4d77.614235?hl=en"
          })
        }
        else if(this.selectedRes=="Nagarjuna Chimney"){
          obj["restaurants"].push({
            name:"Nagarjuna Chimney",
            rating:4.2,
            reviews:10817,
            address:"Meu Square, 174/1, Bannerghatta Main Rd, above KFC, Phase 4, J. P. Nagar, Bengaluru, Karnataka 560076",
            openingHours:"7:30am-9:30pm",  
            products:data.Restaurants[4]['restaurants'][2]['products'],
           imgUrl:"https://im1.dineout.co.in/images/uploads/restaurant/sharpen/1/m/o/p1087-149423464959103619c1aea.jpg?tr=tr:n-xlarge",
           url:"https://www.google.com/maps/place/Nagarjuna+Restaurant+-+Bannerghatta+Main+Road/@12.9061831,77.5707735,14z/data=!4m8!1m2!2m1!1snagarjuna+jp+nagar!3m4!1s0x3bae1519511aa863:0x46395c4ec10a021e!8m2!3d12.9049026!4d77.6015639?hl=en"
          })
        }
      }
      this._service.addRestaurants(obj).subscribe(data=>this._snackBar.open("Added Restaurant Successfully","OK",{
        duration:2000
            }))
    })
   
  }
  ngOnInit() {
  }

}
