import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminComponent } from './admin/admin.component';
import { RefundComponent } from './refund/refund.component';
import { MatCard, MatCardModule } from '@angular/material/card';
import { MatDividerModule } from '@angular/material/divider';
import { RouterModule } from '@angular/router';
import { FoodZoneModule } from '../food-zone/food-zone.module';
import { MatButtonModule } from '@angular/material/button';
import { AddRestaurantsComponent } from './add-restaurants/add-restaurants.component';
import { AddFoodsComponent } from './add-foods/add-foods.component';
import {MatSelectModule} from '@angular/material/select';
import { MatLabel, MatFormFieldModule } from '@angular/material/form-field';
import { FormsModule } from '@angular/forms';
import { MatTooltipModule } from '@angular/material/tooltip';
import { HttpClientModule } from '@angular/common/http';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatDialogModule } from '@angular/material/dialog';
import { MatInputModule } from '@angular/material/input';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { MatChipsModule } from '@angular/material/chips';
import { MatBadgeModule } from '@angular/material/badge';
import { MatRadioModule } from '@angular/material/radio';
import { RemoveRestaurantComponent } from './remove-restaurant/remove-restaurant.component';
import { RemoveFoodComponent } from './remove-food/remove-food.component';

@NgModule({
  imports: [
    CommonModule,
    MatCardModule,
    MatDividerModule,
    FoodZoneModule,
    MatButtonModule,
    FormsModule,
    MatFormFieldModule,
    MatTooltipModule,   CommonModule,HttpClientModule,MatToolbarModule,MatCardModule,MatSidenavModule,MatButtonModule,MatDividerModule,MatRadioModule,FormsModule,MatBadgeModule
    ,MatDialogModule,MatInputModule,MatSnackBarModule,FoodZoneModule,
    AngularFontAwesomeModule,MatChipsModule,MatBadgeModule,MatSelectModule
  ],
  declarations: [AdminComponent, RefundComponent, AddRestaurantsComponent, AddFoodsComponent, RemoveRestaurantComponent, RemoveFoodComponent],
  exports:[AdminComponent,RefundComponent]
})
export class AdminModule { }
