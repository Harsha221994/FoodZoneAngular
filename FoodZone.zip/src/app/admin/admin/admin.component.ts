import { Component, OnInit } from '@angular/core';
import { FoodService } from 'src/app/home/food.service';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/login/login.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  userName=""

  constructor(private _service:FoodService,private _router:Router,private login:LoginService) { }
  ngOnInit() {
  this.userName=sessionStorage.getItem("userName")
    // this.login.userNameChange.subscribe(value=>{
    //   console.log('valueee')
    //   this.userName=this.login.name
    // })
 //   this._router.navigate(['admin/refunds'])
  }
  addRestauants(){
    this._router.navigate(["admin/addRestaurant"])
  }
  refund(){
    this._router.navigate(['admin/refunds'])
  }
  removeRestaurants(){
this._router.navigate(["admin/removeRestaurant"])
  }
  addFood(){
    this._router.navigate(["admin/addFood"])
  } 
  removeFood(){
    this._router.navigate(["admin/removeFood"])
  }

  logOut(){
    sessionStorage.clear();
    this._router.navigate(['login']);
  }
}
