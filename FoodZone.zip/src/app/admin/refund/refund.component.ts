import { Component, OnInit } from '@angular/core';
import { FoodService } from 'src/app/home/food.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-refund',
  templateUrl: './refund.component.html',
  styleUrls: ['./refund.component.css']
})
export class RefundComponent implements OnInit {

  constructor(private _service:FoodService,private _snackBar:MatSnackBar) { }
  refundList=[]
  getRefundList(){
    this._service.getRefundList().subscribe((data:any)=>this.refundList=data)
  }
  ngOnInit() {
    console.log('inside refund')
   this.getRefundList()
  }
  issueRefund(food,email,price){
    let productID=food.prodID||food.productID 
    this._service.issueRefund(productID,email,price).subscribe(data=>{this._snackBar.open("refund issued Successfully ","OK",{
      duration:2000
          })
          this.getRefundList()
        })
  }


}
