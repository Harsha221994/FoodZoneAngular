import { Component, OnInit } from '@angular/core';
import { FoodService } from 'src/app/home/food.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-remove-food',
  templateUrl: './remove-food.component.html',
  styleUrls: ['./remove-food.component.css']
})
export class RemoveFoodComponent implements OnInit {

  constructor(private _service:FoodService,private _snackBar:MatSnackBar) { }
  FoodList=[]
  ngOnInit() {
    this._service.getAddedFood().subscribe((data:any)=>this.FoodList=data)
  }
  remFood(food){
    this._service.remFood(food).subscribe(data=>{
      this._snackBar.open("Removed Food Successfully","OK",{
      duration:2000
          })
          this._service.getAddedFood().subscribe((data:any)=>this.FoodList=data)
        })
  }

}
