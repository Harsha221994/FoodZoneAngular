import { Component, OnInit } from '@angular/core';
import { FoodService } from 'src/app/home/food.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-remove-restaurant',
  templateUrl: './remove-restaurant.component.html',
  styleUrls: ['./remove-restaurant.component.css']
})
export class RemoveRestaurantComponent implements OnInit {

  constructor(private _service:FoodService,private _snackBar:MatSnackBar) { }
  restaurants=[]
basvanagudiRestaurants=["Truffles","Nagarjuna Chimney"]
JPNagarRestaurants=["Roti ghar","Vijaylakshmi veg"]
  selectedLoc
  selectedRes

  onChange(){
    if(this.selectedLoc=="JP Nagar"){
      this.restaurants=this.basRes
    }
    else if(this.selectedLoc=="Basavanagudi")
  {
    this.restaurants=this.jpRes
  }    
  }
  resList=[]
  basRes=[]
  jpRes=[]
  getAddedRes(){
    this.resList=[]
    this.jpRes=[]
    this.basRes=[]
    this._service.getAddedRes().subscribe((data:any)=>{
      data.forEach(dat=>{
        if(this.resList.indexOf(dat.location)==-1)
          this.resList.push(dat.location)
        debugger          
        if(dat.location=="JP Nagar")
          this.basRes.push(...dat.restaurants.map(res=>res.name))
        else
         this.jpRes.push(...dat.restaurants.map(res=>res.name))
    
    })
     })
  }
 ngOnInit(){
  this.getAddedRes()
}
 removeRes(loc,res){
  this._service.removeRestaurant(res).subscribe(data=>{this._snackBar.open("Removed Restaurant Successfully","OK",{
    duration:2000
        })
        this.selectedRes=""
        this.selectedLoc=""
        this.getAddedRes()
      })
 }

}
