import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule, Router } from '@angular/router';
import { LoginComponent } from '../login/login.component';
import { RegisterComponent } from '../register/register.component';
import { HomeComponent } from '../home/home.component';
import { OffersComponent } from '../home/offers/offers.component';
import { CartComponent } from '../home/cart/cart.component';
import { PaymentComponent } from '../home/payment/payment.component';
import { VegComponent } from '../home/veg/veg.component';
import { NonVegComponent } from '../home/non-veg/non-veg.component';
import { RestaurantComponent } from '../home/restaurant/restaurant.component';
import { RestaurantdetailsComponent } from '../home/restaurantdetails/restaurantdetails.component';
import { ProductComponent } from '../home/product/product.component';
import { WishListComponent } from '../home/wish-list/wish-list.component';
import { OrderComponent } from '../home/order/order.component';
import { AdminComponent } from '../admin/admin/admin.component';
import { RefundComponent } from '../admin/refund/refund.component';
import { AddRestaurantsComponent } from '../admin/add-restaurants/add-restaurants.component';
import { AddFoodsComponent } from '../admin/add-foods/add-foods.component';
import { RemoveRestaurantComponent } from '../admin/remove-restaurant/remove-restaurant.component';
import { RemoveFoodComponent } from '../admin/remove-food/remove-food.component';
import { PickupComponent } from '../home/pickup/pickup.component';
import { DeliveryComponent } from '../home/delivery/delivery.component';
import { WalletComponent } from '../home/wallet/wallet.component';
import { ForgotPasswordComponent } from '../home/forgot-password/forgot-password.component';
import { ResetPasswordComponent } from '../home/reset-password/reset-password.component';
import { CarGuard } from '../car.guard';
import { AuthgaurdGuard } from '../authgaurd.guard';


const routes:Routes=[
  {path:'forgotPassword',component:ForgotPasswordComponent},
  {path:'resetPassword',component:ResetPasswordComponent},
  {path:'home',component:HomeComponent , canActivate:[CarGuard],
  children:
  [
    
    {
    path:'offers',component:OffersComponent},
    {path:'pickup',component:PickupComponent},
    {path:'wallet',component:WalletComponent},
    {path:'delivery',component:DeliveryComponent},
    {
      path:'orders',component:OrderComponent
    },
    {path:"restaurants",component:RestaurantComponent,
    },
    {
      path:"products",component:ProductComponent
    },
    {
      path:"details",component:RestaurantdetailsComponent}
,
  {path:'cart',component:CartComponent},
  {path:'wishList',component:WishListComponent},

  {
    path:'veg',component:VegComponent
  },
  
  {
    path:'nonveg',component:NonVegComponent
  },
{path:'payment',component:PaymentComponent}]},
  {path:'login',component:LoginComponent},
{path:'register',component:RegisterComponent},
{path:'login',component:LoginComponent},
{path:'admin',component:AdminComponent,canActivate:[AuthgaurdGuard],
children:[
  {
  path:'refunds',component:RefundComponent
},
{
  path:'addRestaurant',component:AddRestaurantsComponent
},
{
  path:'removeRestaurant',component:RemoveRestaurantComponent
},
{
  path:'addFood',component:AddFoodsComponent 
},
{
  path:'removeFood',component:RemoveFoodComponent 
},
{
  path:'addFood',component:AddFoodsComponent
},{
  path:'**',component:AddRestaurantsComponent
}
]
},
{
  path:'**',redirectTo:'login'}
]

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ],
  declarations: [],
  exports:[RouterModule]
})
export class FoodZoneModule { }
