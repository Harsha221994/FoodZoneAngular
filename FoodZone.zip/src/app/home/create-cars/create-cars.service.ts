import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CreateCarsService {
  createCars(arg0: { "name": any; "price": any; "year": any; }) {
    return this._service.post("http://localhost:8080/cxcarz/createCar.do",arg0)
  }

  constructor(private _service:HttpClient) { }
}
