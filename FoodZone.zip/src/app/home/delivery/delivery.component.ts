import { Component, OnInit } from '@angular/core';
import { FoodService } from '../food.service';
import { RestaurantdetailsService } from '../restaurantdetails.service';
import { ProductService } from '../product.service';
import { Route } from '@angular/compiler/src/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-delivery',
  templateUrl: './delivery.component.html',
  styleUrls: ['./delivery.component.css']
})
export class DeliveryComponent implements OnInit {

  constructor(private _service:FoodService,private _details:RestaurantdetailsService,private _prodService:ProductService,
    private _router:Router) { }
  deliveryList=[]
  ngOnInit() {
    fetch('assets/products.json').then(data=>data.json()).then(resp=>{
      console.log(resp)
      let tempArry=[]
     resp.Restaurants.forEach(res=>
       tempArry.push(...res.restaurants.filter(rest=>rest.products.length>0))
     )
     this.deliveryList=tempArry
     console.log(this.deliveryList)
    }
      )
  }
  visit(restaurant){
    window.open(restaurant.url,"_blank")
      }
      orderOnline(restaurant){
        console.log(restaurant)
        this._prodService.details=restaurant
        this._router.navigate(["home/products"])
      }

}
