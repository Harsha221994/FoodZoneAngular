import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FoodService {
 cartItems=[]
 wishListItems=[]
 walletMoney=0
  constructor(private _http:HttpClient) { }
  nameChange: Subject<string> = new Subject<string>();

  getOffers=()=>this._http.get('http://localhost:3000/getOffers')
  resetPassword=(email,otp,password)=>this._http.post(`http://localhost:3000/resetPassword`,{email,otp,password})
  getProducts=(type)=>this._http.get(`http://localhost:3000/getProducts?type=${type}`)

  getRefundList=()=>this._http.get(`http://localhost:3000/getRefundList`)
  addToCart=(prod,email)=>
     this._http.post(`http://localhost:3000/addToCart?email=${email}`,{productID:parseInt(prod["prodID"])})
  update=()=> this.nameChange.next()

  addToWishList=(prod,email)=>this._http.post(`http://localhost:3000/addToWishList?email=${email}`,{productID:parseInt(prod["prodID"])})

  getCartItems=(email)=>this._http.get(`http://localhost:3000/getCartItems?email=${email}`)

  getWishListItems=(email)=>this._http.get(`http://localhost:3000/getWishListItems?email=${email}`)
  
  removeFromCart=(prod,email)=>this._http.post(`http://localhost:3000/removeFromCart?email=${email}`,{productID:prod})

  removeFromWishList=(prod,email)=>this._http.post(`http://localhost:3000/removeFromWishList?email=${email}`,{productID:prod})

  addToOrders=(products,email)=>this._http.post(`http://localhost:3000/addToOrders?email=${email}`,{products:products})
  forgotPassword=(email)=>this._http.get(`http://localhost:3000/forgotPassword?email=${email}`)
  getOrders=(email)=>this._http.get(`http://localhost:3000/getOrders?email=${email}`)
  requestRefund=(email,prodID,comments,price)=>this._http.post(`http://localhost:3000/requestRefund?email=${email}`,{prod:prodID,comments:comments,price:price})
  issueRefund=(prodID,email,price)=>this._http.post(`http://localhost:3000/issueRefund`,{prodID:prodID,email:email,price})
  addRestaurants=(obj)=>this._http.post(`http://localhost:3000/addRes`,{res:obj})
  removeRestaurant=(obj)=>this._http.post(`http://localhost:3000/remRes`,{res:obj})
  remFood=(obj)=>this._http.post(`http://localhost:3000/remFood`,obj)
  addFood=(obj)=>this._http.post(`http://localhost:3000/addFood`,obj)
  getAddedFood=()=>this._http.get(`http://localhost:3000/getFoodAdded`)
  getAddedRes=()=>this._http.get(`http://localhost:3000/getRestaurants`)
  getWallet=(email)=>this._http.get(`http://localhost:3000/getWallet?email=${email}`)
  updateWallet=(email,price)=>this._http.post('http://localhost:3000/updateWallet',{email:email,price:price})
}
