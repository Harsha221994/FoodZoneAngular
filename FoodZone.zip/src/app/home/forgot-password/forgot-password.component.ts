import { Component, OnInit } from '@angular/core';
import { FoodService } from '../food.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {
  username=""
  msg=""
  constructor(private _service:FoodService,private _router:Router) {
    console.log('data')
   }
  
   sendOTP(){
    this._service.forgotPassword(this.username).subscribe(data=>this.msg=data['data'])
   }
  ngOnInit() {  
    //this.email=sessionStorage.getItem("email")
    console.log('ngOnInit')
  }

}
