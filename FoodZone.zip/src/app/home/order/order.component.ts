import { Component, OnInit } from '@angular/core';
import { FoodService } from '../food.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css']
})
export class OrderComponent implements OnInit {
  orders=[]
  email=""
  constructor(private _service:FoodService,private _snackBar:MatSnackBar) { }
  ngOnInit() {
    this.email=sessionStorage.getItem("email")
  this._service.getOrders(this.email).subscribe((data:Array<Object>)=>
    {
      let x=data
      this.orders=x.filter(y=>y['isRefunded']==false)
      this.orders.push(...x.filter(y=>y['isRefunded']))
    })    
  }

  refund(food,comments,price){
    this._service.requestRefund(this.email,food['prodID'],comments,price).subscribe(data=>{ this._snackBar.open("Refund requested Successfully","OK",{
      duration:2000
          })
          this._service.getOrders(this.email).subscribe((data:Array<Object>)=>
          {
          let x=data
          console.log(x)
          this.orders=x.filter(y=>y['isRefunded']==false)
          this.orders.push(...x.filter(y=>y['isRefunded']))
          })
        })
  }
}
