import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { FoodService } from '../food.service';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {
  captcha;
  captchaVal;
  email="";
  constructor(private _snackBar:MatSnackBar,private _service:FoodService){}
  generateCaptcha=()=>{
    let alphabets=["a","b","c","d"
  ,"e","f","g","h","i","j","k","l","m","n",
  "o","p","q","r","s","t","u","v","w","x","y","z"
  ]
  
 let a=Math.floor(Math.random()*10)
 let b=Math.floor(Math.random()*10)
 let c=Math.floor(Math.random()*10)
 let d=Math.floor(Math.random()*10)
 let e=Math.floor(Math.random()*10)
 this.captcha=a+""+alphabets[b]+""+alphabets[c]+""+d+""+e
  }

  refresh=()=>{
    this.generateCaptcha()
  }
  ngOnInit() {
    this.generateCaptcha();
    this.email=sessionStorage.getItem("email")
  }
  pay=(captchaVal)=>{
if(captchaVal==this.captcha)
          {
            this._service.updateWallet(this.email,this._service.walletMoney).subscribe(data=>{

              this._service.addToOrders(this._service.cartItems.map(cart=>{return {id:cart['prodID'],price:cart['quantity']*cart['price']} }),this.email).subscribe(data=> {
                this._snackBar.open("payment Made Successfully","OK",{
                duration:2000
                    })
                      this._service.getCartItems(this.email).subscribe((resp:Array<any>)=>{
                       this._service.cartItems=[]
                        this._service.cartItems.push(...resp)
                        this._service.update()
                     })
                     
    
                  })
            })
            
            }
        }
}
