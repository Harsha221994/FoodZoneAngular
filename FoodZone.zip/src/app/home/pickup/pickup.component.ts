import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pickup',
  templateUrl: './pickup.component.html',
  styleUrls: ['./pickup.component.css']
})
export class PickupComponent implements OnInit {

  constructor() { }
  deliveryList=[]
  ngOnInit() {
    fetch('assets/products.json').then(data=>data.json()).then(resp=>{
      console.log(resp)
      let tempArry=[]
     resp.Restaurants.forEach(res=>
       tempArry.push(...res.restaurants.filter(rest=>rest.products.length==0))
     )
     this.deliveryList=tempArry
     console.log(this.deliveryList)
    }
      )
  }
  visit(restaurant){
    window.open(restaurant.url,"_blank")
      }
}
