import { Component, OnInit } from '@angular/core';
import { FoodService } from '../food.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.css']
})
export class ResetPasswordComponent implements OnInit {
msg="OTP is incorrect"
showMsg=false
  constructor(private _service:FoodService,private _router:Router) { }
  resetPassword(email,otp,password){
    this._service.resetPassword(email,otp,password).subscribe(data=>{
      if(data['data']=="success"){
      this._router.navigate(['home/offers'])
    }else{
      this.showMsg=true;
    }
  })

  }


  ngOnInit() {
  }

}
