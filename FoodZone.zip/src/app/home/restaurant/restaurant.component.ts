import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { RestaurantdetailsComponent } from '../restaurantdetails/restaurantdetails.component';
import { Router } from '@angular/router';
import { RestaurantdetailsService } from '../restaurantdetails.service';

@Component({
  selector: 'app-restaurant',
  templateUrl: './restaurant.component.html',
  styleUrls: ['./restaurant.component.css']
})
export class RestaurantComponent implements OnInit {

  constructor(private _http:HttpClient,private _details:RestaurantdetailsService,
    private _router:Router) {

   }

  getRestaurants(location){
    this._details.restaurants=location.restaurants
    this._router.navigate(["home/details"])
  }
  restaurants=[]
  ngOnInit() {
    this._http.get("assets/products.json").subscribe((data:Array<any>)=>{
      console.log(data)
      this.restaurants.push(...data['Restaurants'])
    })
    this._http.get('http://localhost:3000/getRestaurant').subscribe((data:any)=>
    {
      this.restaurants.unshift(...data)
    })
  }

}
