import { TestBed } from '@angular/core/testing';

import { RestaurantdetailsService } from './restaurantdetails.service';

describe('RestaurantdetailsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: RestaurantdetailsService = TestBed.get(RestaurantdetailsService);
    expect(service).toBeTruthy();
  });
});
