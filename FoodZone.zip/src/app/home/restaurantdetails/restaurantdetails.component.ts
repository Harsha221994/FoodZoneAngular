import { Component, OnInit } from '@angular/core';
import { RestaurantdetailsService } from '../restaurantdetails.service';
import { ProductService } from '../product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-restaurantdetails',
  templateUrl: './restaurantdetails.component.html',
  styleUrls: ['./restaurantdetails.component.css']
})
export class RestaurantdetailsComponent implements OnInit {

  restaurantsDetails=[]
  constructor(private _details:RestaurantdetailsService,private _prodService:ProductService,
    private _router:Router) { }

  ngOnInit() {
   this.restaurantsDetails= this._details.restaurants
   console.log(this.restaurantsDetails)
  }
  visit(restaurant){
window.open(restaurant.url,"_blank")
  }
  orderOnline(restaurant){
    console.log(restaurant)
    this._prodService.details=restaurant
    this._router.navigate(["home/products"])
  }
}
