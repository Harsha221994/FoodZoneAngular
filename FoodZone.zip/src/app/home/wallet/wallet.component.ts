import { Component, OnInit } from '@angular/core';
import { FoodService } from '../food.service';

@Component({
  selector: 'app-wallet',
  templateUrl: './wallet.component.html',
  styleUrls: ['./wallet.component.css']
})
export class WalletComponent implements OnInit {
  price
  email
  img="assets/wallet.webp"
  constructor(private _service:FoodService) { }

  ngOnInit() {
    this.email=sessionStorage.getItem("email")
    this._service.getWallet(this.email).subscribe(data=>{
      this.price=data['price']
    })
  }

}
