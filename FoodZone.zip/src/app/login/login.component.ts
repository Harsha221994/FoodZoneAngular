import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from './login.service'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

username:string = '';
password : string= '';
errormsg : string;
err:boolean

checkEmail:boolean
  constructor(private _route:Router, private _loginService:LoginService) { }
  login()
    {
      console.log(this.username,this.password);
        this._loginService.loginUser(this.username,this.password)
                          .subscribe(
                  data=>{
                    console.log(data)
                    if(data['data']==true){
                      this._loginService.name=data['name']
                      sessionStorage.setItem("userName",data['name'])
                      sessionStorage.setItem('isAdmin',"true")
                      this._loginService.isLoggedIn=true;
                      this._loginService.isAdmin=true
                      this._route.navigate(["admin"])
                    }
                   else  if(data['data']=="success"){
                      this.err=false
                      this._loginService.name=data['name']
                      this._loginService.updateName()
                       this._loginService.isLoggedIn=true;
                       sessionStorage.setItem("userName",data['name']);
                       sessionStorage.setItem("email",this.username);
                        this._route.navigate(['home']);
                  }
                  else if(data['data']=="Please verify your Email ID before Login !! "){
                    this.checkEmail=true
                    this.err=false
                  }
                  else{
                    this.err=true
                    this.checkEmail=false
                  }
            
                }
                )
      

    }
   
    forgotPassword(){
      this._route.navigate(["forgotPassword"])
    }
  navigateToRegister(){
    this._route.navigate(['/register']);
  }
  ngOnInit() {
  }

}
