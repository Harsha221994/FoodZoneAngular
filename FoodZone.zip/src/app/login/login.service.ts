import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
isLoggedIn:boolean=false;
name=""
isAdmin:boolean=false;
userNameChange: Subject<string> = new Subject<string>();
  constructor(private _service:HttpClient) { 
  }
  loginUser(email,password){
    return this._service.post("http://localhost:3000/login",{"emailId":email,"password":password})
  }
 updateName=()=>this.userNameChange.next()

  forgotPass(email){
    return this._service.get(`http://localhost:3000/forgotPassword?email=${email}`)
  }
}
