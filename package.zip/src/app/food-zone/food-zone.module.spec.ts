import { FoodZoneModule } from './food-zone.module';

describe('FoodZoneModule', () => {
  let foodZoneModule: FoodZoneModule;

  beforeEach(() => {
    foodZoneModule = new FoodZoneModule();
  });

  it('should create an instance', () => {
    expect(foodZoneModule).toBeTruthy();
  });
});
