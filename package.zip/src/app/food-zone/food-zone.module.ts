import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule, Router } from '@angular/router';
import { LoginComponent } from '../login/login.component';
import { RegisterComponent } from '../register/register.component';
import { HomeComponent } from '../home/home.component';
import { OffersComponent } from '../home/offers/offers.component';
import { CartComponent } from '../home/cart/cart.component';
import { PaymentComponent } from '../home/payment/payment.component';
import { VegComponent } from '../home/veg/veg.component';
import { NonVegComponent } from '../home/non-veg/non-veg.component';
import { RestaurantComponent } from '../home/restaurant/restaurant.component';
import { RestaurantdetailsComponent } from '../home/restaurantdetails/restaurantdetails.component';
import { ProductComponent } from '../home/product/product.component';


const routes:Routes=[
  {path:'home',component:HomeComponent ,
  children:
  [{path:'offers',component:OffersComponent},
    {path:"restaurants",component:RestaurantComponent,
    },
    {
      path:"products",component:ProductComponent
    },
    {
      path:"details",component:RestaurantdetailsComponent}
,
  {path:'cart',component:CartComponent},
  {
    path:'veg',component:VegComponent
  },
  {
    path:'nonveg',component:NonVegComponent
  },
{path:'payment',component:PaymentComponent}]},
  {path:'login',component:LoginComponent},
{path:'register',component:RegisterComponent},
{path:'login',component:LoginComponent},

{
  path:'**',redirectTo:'login'}
]

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ],
  declarations: [],
  exports:[RouterModule]
})
export class FoodZoneModule { }
