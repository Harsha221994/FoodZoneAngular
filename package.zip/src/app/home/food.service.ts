import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FoodService {
 cartItems=[]
 wishListItems=[]
  constructor(private _http:HttpClient) { }
  nameChange: Subject<string> = new Subject<string>();

  getOffers=()=>this._http.get('http://localhost:3000/getOffers')

  getProducts=(type)=>this._http.get(`http://localhost:3000/getProducts?type=${type}`)

  addToCart=(prod,email)=>
     this._http.post(`http://localhost:3000/addToCart?email=${email}`,{productID:prod["prodID"]})
  update=()=> this.nameChange.next()

  addToWishList=(prod,email)=>this._http.post(`http://localhost:3000/addToWishList?email=${email}`,{productID:prod["prodID"]})

  getCartItems=(email)=>this._http.get(`http://localhost:3000/getCartItems?email=${email}`)

  getWishListItems=(email)=>this._http.get(`http://localhost:3000/getWishListItems?email=${email}`)
  
  removeFromCart=(prod,email)=>this._http.post(`http://localhost:3000/removeFromCart?email=${email}`,{productID:prod})

  removeFromWishList=(prod,email)=>this._http.post(`http://localhost:3000/removeFromWishList?email=${email}`,{productID:prod})

}
