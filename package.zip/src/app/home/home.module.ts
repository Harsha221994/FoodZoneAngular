import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomeComponent } from './home.component';
import { HomeService } from './home.service';
import { HttpClientModule } from '@angular/common/http';
import {MatToolbarModule} from '@angular/material/toolbar';
import { MatCardModule } from '@angular/material/card';
import {MatSidenavModule} from '@angular/material/sidenav';
import {MatButtonModule} from '@angular/material/button';
import {MatDividerModule} from '@angular/material/divider';
import { StoresComponent } from './stores/stores.component';
import { CartComponent } from './cart/cart.component';
import { PaymentComponent } from './payment/payment.component';
import {MatRadioModule} from '@angular/material/radio';
import { FormsModule } from '@angular/forms';
import {MatBadgeModule} from '@angular/material/badge';
import {MatDialogModule} from '@angular/material/dialog';
import { MatInputModule } from '@angular/material/input';
import {MatSnackBarModule} from '@angular/material/snack-bar';
import { CreateCarsComponent } from './create-cars/create-cars.component';
import { OffersComponent } from './offers/offers.component';
import { FoodZoneModule } from '../food-zone/food-zone.module';
import {MatChipsModule} from '@angular/material/chips';
import {MatTooltipModule} from '@angular/material/tooltip';

import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { WishListComponent } from './wish-list/wish-list.component';
import { VegComponent } from './veg/veg.component';
import { NonVegComponent } from './non-veg/non-veg.component';
import { RestaurantComponent } from './restaurant/restaurant.component';
import { RestaurantdetailsComponent } from './restaurantdetails/restaurantdetails.component';
import { ProductComponent } from './product/product.component';
@NgModule({
  imports: [
    MatTooltipModule,   CommonModule,HttpClientModule,MatToolbarModule,MatCardModule,MatSidenavModule,MatButtonModule,MatDividerModule,MatRadioModule,FormsModule,MatBadgeModule
    ,MatDialogModule,MatInputModule,MatSnackBarModule,FoodZoneModule,
    AngularFontAwesomeModule,MatChipsModule,MatBadgeModule
  ],
  entryComponents:[],
  declarations: [HomeComponent,  CartComponent, PaymentComponent,  OffersComponent, WishListComponent, VegComponent, NonVegComponent, RestaurantComponent, RestaurantdetailsComponent, ProductComponent],
  providers : [HomeService],
  exports :[HomeComponent]
})
export class HomeModule { }
