import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class HomeService {

  constructor(private _http:HttpClient) { }
  cartTotal;
  getOffers(){
    return this._http.get('http://localhost:3000/getOffers');
  }

  getSelectedBrand(url){
    return this._http.get(url);

  }
}
