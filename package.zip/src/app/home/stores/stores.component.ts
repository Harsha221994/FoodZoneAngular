import { Component, OnInit } from '@angular/core';
import { CardetailsService } from '../cardetails.service';

@Component({
  selector: 'app-stores',
  templateUrl: './stores.component.html',
  styleUrls: ['./stores.component.css']
})
export class StoresComponent implements OnInit {
  selectedCar=[]
  storesList

  goToLoc(store){
    window.open(store.loc)
  }
  constructor(private _service:CardetailsService) { 
        console.log(this._service.selectedCar,this._service.storesList)

    this.selectedCar=[this._service.selectedCar]
    let obj=this._service.storesList[0]
    this.storesList=obj[Object.keys(obj)[0]]

  }
  ngOnInit(){
  }
}
