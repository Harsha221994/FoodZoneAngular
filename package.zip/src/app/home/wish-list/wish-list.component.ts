import { Component, OnInit } from '@angular/core';
import { FoodService } from '../food.service';

@Component({
  selector: 'app-wish-list',
  templateUrl: './wish-list.component.html',
  styleUrls: ['./wish-list.component.css']
})
export class WishListComponent implements OnInit {

  constructor(private _food:FoodService) { }

  ngOnInit() {
    
  }
  removeFromWishList(food){
    this._food.removeFromWishList(food["prodID"],"harshagowda994@gmail.com")
        .subscribe(data=>console.log(data))
  }


}
