import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
isLoggedIn:boolean=false;

  constructor(private _service:HttpClient) { 
  }
  loginUser(email,password){
    return this._service.post("http://localhost:3000/login",{"emailId":email,"password":password})
  }

}
