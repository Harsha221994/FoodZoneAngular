import { Component, OnInit } from '@angular/core';
import { HomeService } from './home.service';
import { Router } from '@angular/router'
import { FoodService } from './food.service';
@Component({

  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  userName:string;
  carMakes=[];
  cartLength: number;
  wishListLength:number;
  goToCart(){
    this._router.navigate(['home/cart']);
  }
  goToWishList(){
    this._router.navigate(['home/wishList']);
  }
 
  cartTotal
  offers(){
    this._router.navigate(["home/offers"])
  }
  constructor(private _service:HomeService, private _router:Router,private food:FoodService) { 
    //this.cartTotal=_service.cartTotal;
    this.food.nameChange.subscribe(value=>{
      console.log("inside sub")
      console.error(this.food.cartItems.length)
      this.cartLength=this.food.cartItems.length
      this.wishListLength=this.food.wishListItems.length
    })
  }

  goToRestaurants(){
    this._router.navigate(["home/restaurants"])
  }

  veg(){
    this._router.navigate(["home/veg"])
  }
  nonVeg(){
    this._router.navigate(["home/nonVeg"])
  }
  viewCart(){
    this._router.navigate(['home/cart'])
  }


email=""
  ngOnInit() {
    this._router.navigate(['home/offers']);
    // this.userName=sessionStorage.getItem('username');
    // return this._service.getCarBrands().subscribe((data)=>{
    //   console.log(data['carMakes']);
    //   this.carMakes=data['carMakes'];
    // });
    this.email=sessionStorage.getItem("email")
   this.getCartItems()
   this.getWishListItems()
  }
  getCartItems(){
    console.error("get Cart items")
    this.food.getCartItems(this.email).subscribe((resp:Array<any>)=>{
      console.error(resp)
      this.food.cartItems.push(...resp)
      this.cartLength=this.food.cartItems.length
      console.log(this.food.cartItems.length)
    })
    
  }
  getWishListItems(){
    this.food.getWishListItems(this.email).subscribe((resp:Array<any>)=>{
      this.food.wishListItems.push(...resp)
      this.wishListLength=this.food.wishListItems.length
      console.log(this.food.wishListItems.length)
    })
  }

  logOut(){
    sessionStorage.clear();
    this._router.navigate(['login']);
  }

  selectBrand(brand){
    // alert(brand);
      // console.log(brand);
      // this._service.getSelectedBrand(brand.url).subscribe((data)=>{
      //   console.log(data);
      // }, ()=>{});

    //this._router.navigate(['home/carDetails',{brand:JSON.stringify(brand)}]);
      

    }
  

}
