import { Component, OnInit, ViewChild, Output } from '@angular/core';
import { FoodService } from '../food.service';
import { HomeService } from '../home.service';
import { HomeComponent } from '../home.component';
import { EventEmitter } from '@angular/core';

@Component({
  selector: 'app-offers',
  templateUrl: './offers.component.html',
  styleUrls: ['./offers.component.css']
})
export class OffersComponent implements OnInit {
 email=""
  @Output() event=new EventEmitter()
  constructor(private service:FoodService,private _Home:HomeService) { 
    this.email=sessionStorage.getItem("email")
  }
  offers=[]
  wishLists=[]
  addToWishList(offer,email){
    //email="harshagowda994@gmail.com"
    
    this.service.addToWishList(offer,this.email).subscribe(data=>console.log(data))
    this.service.getWishListItems(this.email).subscribe((resp:Array<any>)=>{
      this.service.wishListItems=[]
       this.service.wishListItems.push(...resp)
       this.service.update()
     })
    
  }
  addToCart(offer,email){
    //email="harshagowda994@gmail.com"
    this.service.addToCart(offer,this.email).subscribe(data=>{
      
       this.service.getCartItems(this.email).subscribe((resp:Array<any>)=>{
        this.service.cartItems=[]
         this.service.cartItems.push(...resp)
         this.service.update()
      })
      
    })
  
     // this.service.getCartItems("harshagowda994@gmail.com").subscribe((resp:Array<any>)=>{
    //   this.service.cartItems.push(...resp)
    // })
  }


  ngOnInit() {
    this.service.getOffers().subscribe((resp:Array<any>)=>{
      this.offers=resp
      console.log(this.offers)
    })
  this.email=sessionStorage.getItem("email")
  }

}
