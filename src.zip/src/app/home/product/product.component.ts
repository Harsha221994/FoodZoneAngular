import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { FoodService } from '../food.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
  email
  constructor(private _service:ProductService,private service : FoodService) { }
  restaurantFood={}
  ngOnInit() {
    this.restaurantFood=this._service.details
    this.email=sessionStorage.getItem("email")
  }
  addToWishList(offer,email){
    //email="harshagowda994@gmail.com"
    this.service.addToWishList(offer,this.email).subscribe(data=>console.log(data))
    this.service.getWishListItems(this.email).subscribe((resp:Array<any>)=>{
      this.service.wishListItems=[]
      this.service.wishListItems.push(...resp)
      this.service.update()
    })
    
  }
  addToCart(offer,email){
  //  email="harshagowda994@gmail.com"
    this.service.addToCart(offer,this.email).subscribe(data=>{

       this.service.getCartItems(this.email).subscribe((resp:Array<any>)=>{
         this.service.cartItems=[]
         this.service.cartItems.push(...resp)
         this.service.update()
      })
      
    })
  
     // this.service.getCartItems("harshagowda994@gmail.com").subscribe((resp:Array<any>)=>{
    //   this.service.cartItems.push(...resp)
    // })
  }
}
