const express= require('express')
const app=express()
const bodyParser=require("body-parser")
const axios=require('axios')

const cors=require("cors")
app.listen(3000,()=>{console.log('started')})
app.use(cors())
//app.use(bodyParser())
app.use(bodyParser.urlencoded({ extended: true, limit: '50mb' }));
//app.use(bodyParser.urlencoded({limit: '50mb'}));
app.use(bodyParser.json({limit: '50mb'}));
let  url="http://webservicescorp.rcf.research.refinitiv.com/BPMService.svc/json";

//Save Entity
app.post("/saveRelation",(req,res)=>{
    let safeID=req.query.safeId
    let json=req.body
    axios.post(`${url}/NEX_SaveRemapdata?safeId=${safeID}`,json).then(data=>{
    res.send("success")
    })
})

//Save Instrument
app.post("/NexLoadInstrumentChangesJSON",(req,res)=>{
    let safeID=req.query.safeId
    let json=req.body
    axios.post(`${url}/NexLoadInstrumentChangesJSON?safeId=${safeID}`,json).then(data=>{
        console.log(data)
    res.send("success")
    })
})

app.get(`/ClearSpecialChar`,(req,res)=>{
        axios.get(`${url}/ClearSpecialChar?orgId=${req.query.orgID}&Lineitemids=${req.query.Lineitemids}`)
        .then(resp=>res.send(resp.data))
})
//?&X-TR-API-APP-ID=Kf42LpNyeoOz13hLYCKsdaq2AvfQaTl0
app.get(`/CheckCompletenessByRepNo`,(req,res)=>{
        axios.get(`${url}/CheckCompletenessByRepNo?CountryCode=${req.query.CountryCode}&repnos=${req.query.repnos}`)
        .then(resp=>res.send(resp.data))
})

app.post("/submitILog",(req,res)=>{
//console.log(req)
        //for QA

        //http://10.91.63.39/ILOGV2/values/submitILogData}
        //http://10.218.74.103/iLogBeta/values/submitILogData
console.log(req.body.raw)
axios.post(`http://10.91.63.39/ILOGV2/values/submitILogData`,req.body.raw).then((resp)=>{
console.log(resp)
res.send(resp.data)},(err)=>console.log(err))
})


app.get('/WFRetrigger',(req,res)=>
axios.get(`${url}/WFRetrigger?ComponentID=${req.query.ComponentID}&WorkflowID=${req.query.WorkflowID}&ComponentTypeID=${req.query.ComponentTypeID}&FROMUI=1`)
	.then(resp=>res.send(resp.data)
))

app.get('/WFGetStatusForWFID',(req,res)=>
axios.get(`${url}/WFGetStatusForWFID?WorkflowID=req.query.WorkflowID}`)
	.then(resp=>res.send(resp.data)
)



//Save WorldScope
app.post("/UpdateBCCutOFFDateByXML_Latest",(req,res)=>{
        axios.post(`${url}/UpdateBCCutOFFDateByXML_Latest`,req.body).then(resp=>res.send(resp.data))
})


app.post("/NexWorlscopeChangesJSON",(req,res)=>{
    let safeID=req.query.safeId
    let json=req.body
    axios.post(`${url}/NexWorlscopeChangesJSON?safeId=${safeID}`,json).then(data=>{
        console.log(data)
    res.send("success")
    })
})

app.get("/WFGetCIPMasterDetailsWithCName",(req,res)=>
                axios.get(`${url}/WFGetCIPMasterDetailsWithCName?DataContentName=${req.query.DataContentName}`)
                     .then(resp=>
                            {   console.log(resp.data)
                                    res.jsonp(resp.data)}
                        ))


                        app.get("/WFGetCIPMasterDetailsWithoutCName",(req,res)=>
                        axios.get(`${url}/WFGetCIPMasterDetailsWithoutCName?TaskGroupName=${req.query.TaskGroupName}`)
                             .then(resp=>
                                    {   console.log(resp.data)
                                            res.jsonp(resp.data)}
                                ))
        
        

//login Page 
app.get("/WFGetsafeLoginDetails",(req,res)=>
                axios.get(`${url}/WFGetsafeLoginDetails?SafeID=${req.query.SafeID}`)
                     .then(resp=>
                            {   console.log(resp.data)
                                    res.jsonp(resp.data)}
                        ))


//MainScreen

//Search By OrgID
app.get("/GetLPSOrganizationByTRFOrgID",(req,res)=>
            axios.get(`${url}/GetLPSOrganizationByTRFOrgID?TRFOrgID=${req.query.TRFOrgID}`)
                 .then(resp=>res.send(resp.data))
);
//Search By Organization ID
app.get("/GetLPSOrganizationByOAPermID",(req,res)=>
            axios.get(`${url}/GetLPSOrganizationByOAPermID?OAPermID=${req.query.OAPermID}`)
                 .then(resp=>res.send(resp.data))
);
//Search By Name
app.get("/GetLPSOrganizationByName",(req,res)=>
            axios.get(`${url}/GetLPSOrganizationByName?OrgName=${req.query.OrgName}`)
                 .then(resp=>res.send(resp.data))
);

//Get All the GeographyNames
app.get("/NEX_GetGeographynames",(req,res)=>
            axios.get(`${url}/NEX_GetGeographynames`)
                 .then(resp=>res.send(resp.data))
);




//Search RepNo to FB
app.get("/Nex_GetRepNo2FBByOrgIDFinancialsBucketID",(req,res)=>
            {
                    axios.get(`${url}/Nex_GetRepNo2FBByOrgIDFinancialsBucketID?OrgID=${req.query.OrgID}`)
                 .then(resp=>res.send(resp.data),(err)=>{resp.send(err)})
                            });


//Main Screen

/***  Entity Screen ****/

//
app.get("/NEX_ReportingEntityCheck?",(req,res)=>
axios.get(`${url}/NEX_ReportingEntityCheck?organisationID=${req.query.organisationID}&reCode=${req.query.reCode}`).then(resp=>res.send(resp.data)))


//check Financials Exist 
 app.get("/NEX_DoesFinancialsExistsForFinancialsBucket",(req,res)=>
    axios.get(`${url}/NEX_DoesFinancialsExistsForFinancialsBucket?OrgID=${req.query.OrgID}`).then(resp=>res.send(resp.data)))

// Get Gaap
app.get("/GetGaap",(req,res)=>
          axios.get(`${url}/GetGaap`).then(resp=>res.send(resp.data)))

//Get Consolidated 
app.get("/GetConsolidationBasis",(req,res)=>
          axios.get(`${url}/GetConsolidationBasis`).then(resp=>res.send(resp.data)))

//
app.get("/GetConsolidationBasis",(req,res)=>
          axios.get(`${url}/GetConsolidationBasis`).then(resp=>res.send(resp.data)))


/***  Entity Screen ***/


/** Instrument Screen */
//Get LPS Instrument 
app.get("/NEXGETLPSInstrumentForOAPermID",(req,res)=>
          axios.get(`${url}/NEXGETLPSInstrumentForOAPermID?OrgPermID=${req.query.OrgPermID}`).then(resp=>res.send(resp.data)))

//Get RE to Instruments
app.get("/NEXGetReportingEntity2Instrument",(req,res)=>
          axios.get(`${url}/NEXGetReportingEntity2Instrument?OrgID=${req.query.OrgID}`).then(resp=>res.send(resp.data)))
          
//Get FB to Instruments
app.get("/NexGetFinancialBucketsforOrgId",(req,res)=>
          axios.get(`${url}/NexGetFinancialBucketsforOrgId?OrgID=${req.query.OrgID}`).then(resp=>res.send(resp.data)))


//Check RE for OrgID
app.get("/NEXGetReportingEntityForOrgID",(req,res)=>
          axios.get(`${url}/NEXGetReportingEntityForOrgID?orgID=${req.query.orgID}`).then(resp=>res.send(resp.data)))

//Check FB exists for Instrument
app.get("/NEX_DoesFinancialsExistsForInstrument",(req,res)=>
          axios.get(`${url}/NEX_DoesFinancialsExistsForInstrument?orgID=${req.query.orgID}&instrumentNDAID=${req.query.instrumentNDAID}`).then(resp=>res.send(resp.data)))



/** Instrument Screen */


/** WS Company */

//Get WorldScope2FB 
app.get("/NEXGetWorldScope2FinancialsBucketForOrgID",(req,res)=>
          axios.get(`${url}/NEXGetWorldScope2FinancialsBucketForOrgID?orgID=${req.query.orgID}`).then(resp=>res.send(resp.data)))
//Get WorldScope companies
app.get("/NexGetWorldScopeCompanyByOrgID",(req,res)=>
          axios.get(`${url}/NexGetWorldScopeCompanyByOrgID?orgID=${req.query.orgID}`).then(resp=>res.send(resp.data)))

//Get FB 2 TRF Instruments
app.get("/NexGetFinancialsBucket2TRFInstrumentsForOrgID",(req,res)=>
axios.get(`${url}/NexGetFinancialsBucket2TRFInstrumentsForOrgID?orgID=${req.query.orgID}&reportingEntityCode=${req.query.reportingEntityCode}&InstrumentNdaID=${req.query.InstrumentNdaID}`).then(resp=>res.send(resp.data)))

        
/** Ws Company */

/** RepNo Remap */
app.get("/NEX_GetREDetailsFromTRF_forOrgID",(req,res)=>
        axios.get(`${url}/NEX_GetREDetailsFromTRF_forOrgID?orgID=${req.query.orgID}`).then(resp=>res.send(resp.data)))


app.get("/NEX_GetREDetailsFromTRF_forOrgID",(req,res)=>
        axios.get(`${url}/NEX_GetREDetailsFromTRF_forOrgID?orgID=${req.query.orgID}`).then(resp=>res.send(resp.data)))

app.get("/NEX_RepnoRemap",(req,res)=>{
        console.log(`${url}/NEX_RepnoRemap?orgId=${req.query.orgId}&newOAId=${req.query.newOAId}&oldOAId=${req.query.oldOAId}&reCode=${req.query.reCode}&nDAOrgID=${req.query.nDAOrgID}&userId=12`)
        axios.get(`${url}/NEX_RepnoRemap?orgId=${req.query.orgId}&newOAId=${req.query.newOAId}&oldOAId=${req.query.oldOAId}&reCode=${req.query.reCode}&nDAOrgID=${req.query.nDAOrgID}&userId=12`)
             .then(resp=>res.send(resp.data))
})


app.get("/NEX_GetREDetailsFromTRF_forOrganisationID",(req,res)=>{
        axios.get(`${url}/NEX_GetREDetailsFromTRF_forOrganisationID?organisationID=${req.query.organisationID}`)
             .then(resp=>res.send(resp.data))
})

app.get("/NEX_GetREDetailsFromTRF_forRECode",(req,res)=>{
        axios.get(`${url}/NEX_GetREDetailsFromTRF_forRECode?reCode=${req.query.reCode}`)
             .then(resp=>res.send(resp.data))
})
app.get("/GetSDITasks",(req,res)=>{
        axios.get(`${url}/GetSDITasks`)
             .then(resp=>res.send(resp.data))
})

app.get("/ResetSDIStatus",(req,res)=>{
        axios.get(`${url}/ResetSDIStatus?DFType=${req.query.DFType}`)
             .then(resp=>res.send(resp.data))
})

app.get("/TRFSignOffForSafeID",(req,res)=>{
        axios.get(`${url}/TRFSignOffForSafeID?SafeID=${req.query.SafeID}&durationdays=${req.query.durationdays}`)
             .then(resp=>res.send(resp.data))
})
app.get("/FundbSignOffForSafeID",(req,res)=>{
        axios.get(`${url}/FundbSignOffForSafeID?SafeID=${req.query.SafeID}&OrgID=${req.query.OrgID}&fromDate=${req.query.fromDate}&toDate=${req.query.toDate}`)
        .then(resp=>res.send(resp.data))
})

app.get("/GetPeriodDetails",(req,res)=>{
        axios.get(`${url}/GetPeriodDetails?orgId=${req.query.orgId}&PeriodEndDate=${req.query.PeriodEndDate}&PeriodicityCode=${req.query.PeriodicityCode}&PeriodLength=${req.query.PeriodLength}`)
        .then(resp=>res.send(resp.data))
})

app.get("/CheckCompletenessByRepNo",(req,res)=>{
        axios.get(`${url}/CheckCompletenessByRepNo?CountryCode=${req.query.CountryCode}&repnos=${req.query.repnos}`)
        .then(resp=>res.send(resp.data))
})

app.get("/ClearSpecialChar",(req,res)=>{
        axios.get(`${url}/ClearSpecialChar?orgId=${req.query.orgId}&Lineitemids=${req.query.Lineitemids}`)
        .then(resp=>res.send(resp.data))
})

app.get("/GetCFUIPer",(req,res)=>{
        axios.get(`${url}/GetCFUIPerformanceStats?Location=${req.query.Location}&CSTdate=${req.query.CSTdate}&localDate=${req.query.localDate}`)
        .then(resp=>res.send(resp.data))
})

//ResetSDIStatus CheckCompletenessByRepNo
/** RepNo Remap */







//Celeritas



//Get the roles
app.get("/getSafeIDUserDetails",(req,res)=>{
    axios.get(`${url}/getSafeIDUserDetails?userID=${req.query.userID}`).then(resp=>res.jsonp(resp.data),(err)=>{console.log("error")
	console.log(err)
})
})





//Update Comments
app.post('/UpdateCommentsForWF',(req,res)=>
             axios.post(`${url}/UpdateCommentsForWF`,req.body).then(resp=>res.send(resp.data))
        )

//Get Automation Status
app.post("/GetAutomationStatus",(req,res)=>
        {
            console.log(req.body)
            axios.post(`${url}/GetAutomationStatus`,req.body).then(resp=>res.send(resp.data),err=>console.log(err))}
)

//Close TRF Tasks
app.get("/WfCloseTask",(req,res)=>
        axios.get(`${url}/WfCloseTask?FWIdentifier=${req.query.FWIdentifier}&OrgID=${req.query.OrgID}&TaskID=${req.query.TaskID}&closedBy=${req.query.closedBy}`,req.body).then(resp=>res.send(resp.data))
)

//Tables 

app.get("/GetWFBrokerPriority",(req,res)=>
        axios.get(`${url}/GetWFBrokerPriority?tableName=${req.query.tableName}&OrgID=${req.query.OrgID}&TaskID=${req.query.TaskID}&closedBy=${req.query.closedBy}`,req.body).then(resp=>res.jsonp(resp.data))
)

app.get("/GetWFIndexPriority",(req,res)=>
        axios.get(`${url}/GetWFIndexPriority?tableName=${req.query.tableName}&OrgID=${req.query.OrgID}&TaskID=${req.query.TaskID}&closedBy=${req.query.closedBy}`,req.body).then(resp=>res.jsonp(resp.data))
)
app.get("/GetWFMxpdbSafeID",(req,res)=>
        axios.get(`${url}/GetWFMxpdbSafeID?tableName=${req.query.tableName}`).then(resp=>res.jsonp(resp.data))
)
app.get("/GetWFOrgIndex",(req,res)=>
        axios.get(`${url}/GetWFOrgIndex?tableName=${req.query.tableName}`).then(resp=>res.jsonp(resp.data))
)
app.get("/GetWFOrgRevenues",(req,res)=>
        axios.get(`${url}/GetWFOrgRevenues?tableName=${req.query.tableName}`).then(resp=>res.jsonp(resp.data))
)
app.get("/WFSmartPriorityRule",(req,res)=>
        axios.get(`${url}/WFSmartPriorityRule?tableName=${req.query.tableName}`).then(resp=>res.jsonp(resp.data))
)
app.get("/WFSmartPriorityRuleType",(req,res)=>
        axios.get(`${url}/WFSmartPriorityRuleType?tableName=${req.query.tableName}`).then(resp=>res.jsonp(resp.data))
)
app.get("/GetWFSmartPriorityTaskGroup",(req,res)=>
        axios.get(`${url}/GetWFSmartPriorityTaskGroup?tableName=${req.query.tableName}`).then(resp=>res.jsonp(resp.data))
)
app.get("/GetWFSmartPriority",(req,res)=>
        axios.get(`${url}/GetWFSmartPriority?tableName=${req.query.tableName}&OrgID=${req.query.OrgID}`).then(resp=>res.jsonp(resp.data))
)
app.get("/GetWFTaskGroup",(req,res)=>
        axios.get(`${url}/GetWFTaskGroup?tableName=${req.query.tableName}`).then(resp=>res.jsonp(resp.data))
)


app.get("/GetWFTaskGroupStatement",(req,res)=>
        axios.get(`${url}/GetWFTaskGroupStatement?tableName=${req.query.tableName}`).then(resp=>res.jsonp(resp.data))
)
app.get("/GetWFTaskHierarchy",(req,res)=>
        axios.get(`${url}/GetWFTaskHierarchy?tableName=${req.query.tableName}`).then(resp=>res.jsonp(resp.data))
)
app.get("/GetWFTaskReference",(req,res)=>
        axios.get(`${url}/GetWFTaskReference?tableName=${req.query.tableName}`).then(resp=>res.jsonp(resp.data))
)
app.post("/WFTableActionsJSON",(req,res)=>
        axios.post(`${url}/WFTableActionsJSON`,req.body).then(resp=>res.jsonp(resp.data))
)
app.get("/GetWFUserGroupOrg",(req,res)=>
        axios.get(`${url}/GetWFUserGroupOrg?tableName=${req.query.tableName}`).then(resp=>res.jsonp(resp.data))
)
app.get("/GetWFUserGroup",(req,res)=>
        axios.get(`${url}/GetWFUserGroup?tableName=${req.query.tableName}`).then(resp=>res.jsonp(resp.data))
)
//ILOG
app.get("/WFCIP2TRFSignOffForSafeID",(req,res)=>
           { console.log(req.query.SafeID,req.query.startDate,req.query.endDate)
                console.log(`${url}/WFCIP2TRFSignOffForSafeID?SafeID=${req.query.SafeID}&startDate=${req.query.startDate}&endDate=${req.query.endDate}`)
                   axios.get(`${url}/WFCIP2TRFSignOffForSafeID?SafeID=${req.query.SafeID}&startDate=${req.query.startDate}&endDate=${req.query.endDate}`)
                 .then(resp=>res.send(resp.data),(err)=>res.send(err))
        }
);