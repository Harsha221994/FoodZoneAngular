import { Component, OnInit } from '@angular/core';
import { FoodService } from '../food.service';

@Component({
  selector: 'app-veg',
  templateUrl: './veg.component.html',
  styleUrls: ['./veg.component.css']
})
export class VegComponent implements OnInit {

  constructor(private _service:FoodService) { }
  vegFood=[]
  ngOnInit() {
    this._service.getProducts("Veg").subscribe((resp:Array<any>)=>{
      this.vegFood=resp['data']
    })
  }

}
