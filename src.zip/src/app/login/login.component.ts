import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from './login.service'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

username:string = '';
password : string= '';
errormsg : string;
err:boolean
checkEmail:boolean
  constructor(private _route:Router, private _loginService:LoginService) { }

  login()
    {
      console.log(this.username,this.password);
        this._loginService.loginUser(this.username,this.password)
                          .subscribe(
                  data=>{
                    console.log(data)
                    if(data['data']=="success"){
                      this.err=false
                       this._loginService.isLoggedIn=true;
                       sessionStorage.setItem("email",this.username);
                        this._route.navigate(['home']);
                  }
                  else if(data['data']=="Please verify your Email ID before Login !! "){
                    this.checkEmail=true
                    this.err=false
                  }
                  else{
                    this.err=true
                    this.checkEmail=false
                  }
            
                }
                )
      

    }
  navigateToRegister(){
    this._route.navigate(['/register']);
  }
  ngOnInit() {
  }

}
