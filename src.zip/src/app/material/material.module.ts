import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatCardModule } from '@angular/material/card';
import { MatSidenavModule } from '@angular/material/sidenav';
import {MatChipsModule} from '@angular/material/chips';

@NgModule({
  imports: [
    CommonModule,MatToolbarModule,MatCardModule,MatSidenavModule,
    MatChipsModule
  ],
  exports:[MatToolbarModule,MatCardModule,MatSidenavModule,
    MatChipsModule],
  declarations: []
})
export class MaterialModule { }
