import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RegisterService } from './register.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})

export class RegisterComponent implements OnInit {

  username : string;
  mobilenum : string;
  mail : string;
  pswd : string;
  cpswd : string;
  gender : string;
  address:string;
  constructor(private _router:Router,private _service:RegisterService) { }

  formSubmit(){
    console.log(this.username);
    console.log(this.mobilenum);
    console.log(this.mail);
    console.log(this.pswd);
    const user={
      name:this.username,
      phone:this.mobilenum,
      email:this.mail,
      password:this.pswd,
      gender:this.gender,
      address:this.address,
    }
    this._service.saveUser(user).subscribe(data=>
      {
        this.navigateToLogin()
      }
      )
  }

  navigateToLogin(){
    this._router.navigate(['login']);
  }
  emailExists=false;
  checkEmail(){
    this._service.checkEmail(this.mail).subscribe(data=>{
      if(data!=null)
        this.emailExists=true
      else 
        this.emailExists=false
    })
  }
  ngOnInit() {
  }

}
